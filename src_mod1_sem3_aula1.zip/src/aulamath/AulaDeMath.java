package aulamath;

import java.util.Random;

public class AulaDeMath {

  public static void main(String[] args) {
    double potencia = Math.pow(5, 2);
    System.out.println(potencia);

    double raizQuadrada = Math.sqrt(9);
    System.out.println(raizQuadrada);

    double raizCubica = Math.cbrt(27);
    System.out.println(raizCubica);

    double absoluto = Math.abs(-10);
    System.out.println(absoluto);

    double resultFloor = Math.floor(29.9);
    System.out.println(resultFloor);

    double resultCeil = Math.ceil(30.1);
    System.out.println(resultCeil);

    double resultRound = Math.round(4.5);
    System.out.println(resultRound);

    System.out.println(Math.PI);

    double random = Math.random();
    System.out.println(random);

    double aleatorio = Math.random() * (5 - 1) + 1;
    System.out.println("Número aleatório entre 1 e 5: " + aleatorio);

    int aleatorioInteiro = (int) (Math.random() * (10 - 1) + 1);
    System.out.println("Inteiro aleatório entre 0 e 10: " + aleatorioInteiro);


    Random random1 = new Random();
    int aleatorioRandom = random1.nextInt(10-5) + 5;
    System.out.println(aleatorioRandom);

    int idade = 18;

    String status = idade >= 18 ? "maior de idade" : "menor de idade";
    System.out.println(status);

    double media = 6.9;

    String aprovacao = media >= 7.0 ? "Aprovado" : "Reprovado";
    System.out.println(aprovacao);

    boolean ehImpar = (idade % 2 != 0) ? true : false;
    System.out.println("a idade é impar? " + ehImpar);
  }
}

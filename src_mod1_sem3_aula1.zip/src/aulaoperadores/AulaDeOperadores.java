package aulaoperadores;

public class AulaDeOperadores {
  public static void main(String[] args) {
    double nota1 = 8.0;
    double nota2 = 7.0;
    double nota3 = 8.5;
    int qtdNotas = 3;
    double media = (nota1 + (nota2 + nota3)) / qtdNotas;
    System.out.println(media);

    // media ponderada
    double notaProva = 7;
    double notaParticipacao = 7;
    // double mediaModulo1 = (notaProva * 7 + notaParticipacao * 3) / 10;
    double mediaModulo1 = notaProva * 0.7 + notaParticipacao * 0.3;

    System.out.println(mediaModulo1);

    if (mediaModulo1 >= 7.0) {
      System.out.println("Parabéns, você está classificado para o Módulo 2.");
    } else {
      System.out.println("Infelizmente você não atingiu média 7,0. Não se preocupe, você pode fazer a prova de recuperação.");
    }

    double idade = 30;

    // idade = idade + 1;
    // idade += 1;
    idade++;
    idade--;
    ++idade;
    --idade;

    System.out.println(++idade);

    if (idade % 2 == 0) {
      System.out.println("sua idade é par");
    } else {
      System.out.println("sua idade é ímpar");
    }

    /*//idade = idade * 2;
    idade *= 2;
    //idade = idade / 2;
    idade /= 2;
    //idade = idade - 15;
    idade -= 15;
    //idade = idade % 2;
    idade %= 2;*/

    String carro = "gol";

    if (!carro.equals("fusca")) {
      System.out.println("Seu carro não é um fusca");
    }

    String nome = "joão";

    if (nome.equals("João")) {
      System.out.println(nome);
    }

    if (idade != 30) {
      System.out.println("Você não tem 30 anos");
    }

    if (idade % 2 != 0) {
      System.out.println("idade ímpar");
    } else {
      System.out.println("idade par");
    }


    if (7+8+3 > 10 && 10 % 3 == 0) {
      System.out.println("verdadeiro");
    } else {
      System.out.println("falso");
    }

    if (7+8+3 > 10 || 10 % 3 == 0) {
      System.out.println("verdadeiro");
    } else {
      System.out.println("falso");
    }

    if (3 > (2 + 5) * 2 && 7 % 3 == 0) {
      System.out.println("entrou no if");
    } else {
      System.out.println("caiu no else");
    }

  }
}

package operacoescomstring;

import java.util.Scanner;

public class AulaDeOperacoesString {
  public static void main(String[] args) {

    Scanner entrada = new Scanner(System.in);
    
    String nome = "João";
    System.out.println(nome.length());
    System.out.println("João Victor".length());

    System.out.println("Digite seu nome:");
    String nomeDoUsuario = entrada.nextLine();

    System.out.printf("%s, seu nome possui %d caracteres.%n",
        nomeDoUsuario, nomeDoUsuario.length());

    System.out.println();

    System.out.println(nomeDoUsuario.toLowerCase());
    System.out.println(nomeDoUsuario.toUpperCase());

    System.out.println(" nome do usuario @ email. com ".trim());

    System.out.println("João".equals("joão"));
    System.out.println("João".equalsIgnoreCase("joão"));

    System.out.println(nomeDoUsuario.charAt(0));

    System.out.println("Digite seu primeiro e último nome:");
    String nomeCompletoDoUsuario = entrada.nextLine();

    // "João Oliveira"

    String primeiraLetraNome = String.valueOf(nomeCompletoDoUsuario.charAt(0));

    int indiceDoEspaco = nomeCompletoDoUsuario.indexOf(" ");

    char primeiraLetraSobrenome = nomeCompletoDoUsuario.charAt(indiceDoEspaco+1);

    /*System.out.printf("%s, suas iniciais são: %s%s",
        nomeCompletoDoUsuario, nomeCompletoDoUsuario.charAt(0),
        nomeCompletoDoUsuario.charAt(nomeCompletoDoUsuario.indexOf(" ") + 1));*/

    System.out.printf("%s, suas iniciais são: %s%s",
        nomeCompletoDoUsuario, primeiraLetraNome, primeiraLetraSobrenome);

    System.out.println();

    System.out.println(nomeCompletoDoUsuario.indexOf("e"));
    System.out.println(nomeCompletoDoUsuario.lastIndexOf("e"));

    String nomeSemEspacos = nomeCompletoDoUsuario.replace(" ", "");

    System.out.println(nomeSemEspacos);
    System.out.println(nomeSemEspacos.length());
    System.out.println(nomeCompletoDoUsuario);

    System.out.println(nomeCompletoDoUsuario.substring(indiceDoEspaco+1));
    System.out.println(nomeCompletoDoUsuario.substring(0, indiceDoEspaco));

    System.out.println(" ".isEmpty());
    System.out.println(" ".isBlank());

    System.out.printf("Oi%nTchau%nAdeus");
  }
}

package conversaodetipos;


import java.util.Scanner;

public class AulaDeConversao {
  public static void main(String[] args) {
    int idade = 31;
    double altura = 0;
    boolean praticaEsporte = true;

    int alturaInt = (int) altura;

    // idade = "Joao";

    // String nome = idade;

    String nome = "João";

    String idadeStr = Integer.toString(idade);

    System.out.println(idadeStr);

    altura = Double.parseDouble("1.75");

    //System.out.println(altura);

    Scanner entrada = new Scanner(System.in);

    System.out.println("Digite sua altura (números com casa decimal separado por .):");
    String alturaStr = entrada.nextLine();

    altura = Double.parseDouble(alturaStr);

    System.out.println(altura);
  }
}

package tiposdedados;

import java.util.Scanner;

public class AulaDeTipos {
  public static void main(String[] args) {
    double altura = 1.75;

    long identificador = 2147483648l;

    System.out.println(identificador);

    float alturaFloat = 1.75f;

    System.out.println(alturaFloat + altura); //soma os valores
    System.out.println("texto" + alturaFloat + altura); //concatena os valores

    int alturaInt = (int) 1.75;

    System.out.println(alturaInt);

    System.out.printf("Minha altura é: %.2f %n", altura);

    String nomeCompleto = "João Victor Oliveira";
    int idade = 31;

    System.out.println("Minha altura é: " + 1.75 + ". E meu nome é: " + nomeCompleto + ". E minha idade é: " + idade + ".");

    System.out.printf("Minha altura é: %.2f. E meu nome é: %s. E minha idade é: %d.%n", altura, nomeCompleto, idade);
  }
}

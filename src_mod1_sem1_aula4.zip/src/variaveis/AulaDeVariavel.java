package variaveis;

import java.util.Scanner;

public class AulaDeVariavel {
  public static void main(String[] args) {
    int anoAtual = 2022;
    int anoNascimentoUsuario = 1991;
    String nome = "J";

    int idade = anoAtual - anoNascimentoUsuario;

    int iDade;

    iDade = 32;

    char primeiraLetra = 'J';

    double altura = 1.75;

    boolean casado = true;

    String nomeCompleto = "João Victor Oliveira";

    System.out.println(nomeCompleto);

    final double CONSTANTE_PI = 3.14;
  }
}

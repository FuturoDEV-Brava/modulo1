package entradadedados;

import java.util.Scanner;

public class AulaDeEntradaDeDados {
  public static void main(String[] args) {
    /*System.out.println("TESTANDO COMENTÁRIOS");
    System.out.println("OUTRA LINHA DE COMENTÁRIO");*/

    Scanner scanner = new Scanner(System.in);

    System.out.println("Digite seu nome:");
    String nomeDoUsuario = scanner.nextLine();

    System.out.printf("%s, digite sua cidade natal:%n", nomeDoUsuario);
    String cidadeDoUsuario = scanner.nextLine();

    System.out.printf("%s, digite sua idade:%n", nomeDoUsuario);
    int idadeDoUsuario = scanner.nextInt();

    System.out.printf("%s, você é casado(a):%n", nomeDoUsuario);
    boolean teste = scanner.nextBoolean();

    System.out.printf("%s, você nasceu em %s, há %d anos.", nomeDoUsuario, cidadeDoUsuario, idadeDoUsuario);
  }
}
